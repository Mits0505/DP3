package factory.phone;

public interface OS {
   void spec();
}
